import EditAtividades from '../../../components/pages/EditAtividades/EditAtividades';

export default function AtividadesEdit() {
  return <EditAtividades />;
}
