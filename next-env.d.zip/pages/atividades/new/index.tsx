import NewAtividade from '../../../components/pages/EditAtividades/CriarAtividades';

export default function AtividadeNew() {
  return <NewAtividade />;
}
